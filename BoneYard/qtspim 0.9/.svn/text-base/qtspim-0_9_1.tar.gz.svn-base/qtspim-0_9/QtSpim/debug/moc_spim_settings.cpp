/****************************************************************************
** Meta object code from reading C++ file 'spim_settings.h'
**
** Created: Mon Oct 11 21:11:15 2010
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../spim_settings.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'spim_settings.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_Ui__SpimSettingDialog[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      25,   23,   22,   22, 0x0a,
      48,   46,   22,   22, 0x0a,
      71,   46,   22,   22, 0x0a,
      99,   23,   22,   22, 0x0a,
     121,   46,   22,   22, 0x0a,
     145,   46,   22,   22, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_Ui__SpimSettingDialog[] = {
    "Ui::SpimSettingDialog\0\0f\0setRegWinFont(QFont)\0"
    "c\0setRegWinColor(QColor)\0"
    "setRegWinBackground(QColor)\0"
    "setTextWinFont(QFont)\0setTextWinColor(QColor)\0"
    "setTextWinBackground(QColor)\0"
};

const QMetaObject Ui::SpimSettingDialog::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_Ui__SpimSettingDialog,
      qt_meta_data_Ui__SpimSettingDialog, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &Ui::SpimSettingDialog::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *Ui::SpimSettingDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *Ui::SpimSettingDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Ui__SpimSettingDialog))
        return static_cast<void*>(const_cast< SpimSettingDialog*>(this));
    if (!strcmp(_clname, "SettingDialog"))
        return static_cast< SettingDialog*>(const_cast< SpimSettingDialog*>(this));
    return QObject::qt_metacast(_clname);
}

int Ui::SpimSettingDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: setRegWinFont((*reinterpret_cast< QFont(*)>(_a[1]))); break;
        case 1: setRegWinColor((*reinterpret_cast< QColor(*)>(_a[1]))); break;
        case 2: setRegWinBackground((*reinterpret_cast< QColor(*)>(_a[1]))); break;
        case 3: setTextWinFont((*reinterpret_cast< QFont(*)>(_a[1]))); break;
        case 4: setTextWinColor((*reinterpret_cast< QColor(*)>(_a[1]))); break;
        case 5: setTextWinBackground((*reinterpret_cast< QColor(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 6;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
