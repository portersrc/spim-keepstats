/****************************************************************************
** Meta object code from reading C++ file 'settablecheckbox.h'
**
** Created: Mon Oct 11 21:11:17 2010
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../settablecheckbox.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'settablecheckbox.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_settableCheckBox[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      18,   17,   17,   17, 0x0a,
      24,   17,   17,   17, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_settableCheckBox[] = {
    "settableCheckBox\0\0set()\0unset()\0"
};

const QMetaObject settableCheckBox::staticMetaObject = {
    { &QCheckBox::staticMetaObject, qt_meta_stringdata_settableCheckBox,
      qt_meta_data_settableCheckBox, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &settableCheckBox::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *settableCheckBox::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *settableCheckBox::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_settableCheckBox))
        return static_cast<void*>(const_cast< settableCheckBox*>(this));
    return QCheckBox::qt_metacast(_clname);
}

int settableCheckBox::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCheckBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: set(); break;
        case 1: unset(); break;
        default: ;
        }
        _id -= 2;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
