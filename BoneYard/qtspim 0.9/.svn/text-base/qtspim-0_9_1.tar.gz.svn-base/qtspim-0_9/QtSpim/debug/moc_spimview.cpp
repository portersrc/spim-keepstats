/****************************************************************************
** Meta object code from reading C++ file 'spimview.h'
**
** Created: Sat Oct 23 18:10:30 2010
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../spimview.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'spimview.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_SpimView[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
      40,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      10,    9,    9,    9, 0x0a,
      26,    9,    9,    9, 0x0a,
      44,    9,    9,    9, 0x0a,
      63,    9,    9,    9, 0x0a,
      76,    9,    9,    9, 0x0a,
      88,    9,    9,    9, 0x0a,
     109,    9,    9,    9, 0x0a,
     137,    9,    9,    9, 0x0a,
     160,    9,    9,    9, 0x0a,
     170,    9,    9,    9, 0x0a,
     182,    9,    9,    9, 0x0a,
     193,    9,    9,    9, 0x0a,
     210,    9,    9,    9, 0x0a,
     231,    9,    9,    9, 0x0a,
     246,    9,    9,    9, 0x0a,
     266,    9,    9,    9, 0x0a,
     285,    9,    9,    9, 0x0a,
     302,    9,    9,    9, 0x0a,
     332,  327,  323,    9, 0x0a,
     409,  355,  323,    9, 0x0a,
     466,    9,    9,    9, 0x0a,
     489,    9,    9,    9, 0x0a,
     514,    9,    9,    9, 0x0a,
     537,    9,    9,    9, 0x0a,
     568,    9,    9,    9, 0x0a,
     591,    9,    9,    9, 0x0a,
     615,    9,    9,    9, 0x0a,
     640,    9,    9,    9, 0x0a,
     661,    9,    9,    9, 0x0a,
     681,    9,    9,    9, 0x0a,
     699,    9,    9,    9, 0x0a,
     721,  327,  323,    9, 0x0a,
     752,    9,    9,    9, 0x0a,
     771,    9,    9,    9, 0x0a,
     789,    9,    9,    9, 0x0a,
     807,    9,    9,    9, 0x0a,
     825,    9,    9,    9, 0x0a,
     839,    9,    9,    9, 0x0a,
     850,    9,    9,    9, 0x0a,
     866,    9,    9,    9, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_SpimView[] = {
    "SpimView\0\0file_LoadFile()\0file_ReloadFile()\0"
    "file_SaveLogFile()\0file_Print()\0"
    "file_Exit()\0sim_ClearRegisters()\0"
    "sim_ReinitializeSimulator()\0"
    "sim_SetRunParameters()\0sim_Run()\0"
    "sim_Pause()\0sim_Stop()\0sim_SingleStep()\0"
    "sim_DisplaySymbols()\0sim_Settings()\0"
    "reg_DisplayBinary()\0reg_DisplayOctal()\0"
    "reg_DisplayHex()\0reg_DisplayDecimal()\0"
    "int\0base\0setCheckedRegBase(int)\0"
    "base,actionBinary,actionOctal,actionDecimal,actionHex\0"
    "setBaseInternal(int,QAction*,QAction*,QAction*,QAction*)\0"
    "text_DisplayUserText()\0text_DisplayKernelText()\0"
    "text_DisplayComments()\0"
    "text_DisplayInstructionValue()\0"
    "data_DisplayUserData()\0data_DisplayUserStack()\0"
    "data_DisplayKernelData()\0data_DisplayBinary()\0"
    "data_DisplayOctal()\0data_DisplayHex()\0"
    "data_DisplayDecimal()\0"
    "setCheckedDataSegmentBase(int)\0"
    "win_IntRegisters()\0win_FPRegisters()\0"
    "win_TextSegment()\0win_DataSegment()\0"
    "win_Console()\0win_Tile()\0help_ViewHelp()\0"
    "help_AboutSPIM()\0"
};

const QMetaObject SpimView::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_SpimView,
      qt_meta_data_SpimView, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &SpimView::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *SpimView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *SpimView::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_SpimView))
        return static_cast<void*>(const_cast< SpimView*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int SpimView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: file_LoadFile(); break;
        case 1: file_ReloadFile(); break;
        case 2: file_SaveLogFile(); break;
        case 3: file_Print(); break;
        case 4: file_Exit(); break;
        case 5: sim_ClearRegisters(); break;
        case 6: sim_ReinitializeSimulator(); break;
        case 7: sim_SetRunParameters(); break;
        case 8: sim_Run(); break;
        case 9: sim_Pause(); break;
        case 10: sim_Stop(); break;
        case 11: sim_SingleStep(); break;
        case 12: sim_DisplaySymbols(); break;
        case 13: sim_Settings(); break;
        case 14: reg_DisplayBinary(); break;
        case 15: reg_DisplayOctal(); break;
        case 16: reg_DisplayHex(); break;
        case 17: reg_DisplayDecimal(); break;
        case 18: { int _r = setCheckedRegBase((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 19: { int _r = setBaseInternal((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QAction*(*)>(_a[2])),(*reinterpret_cast< QAction*(*)>(_a[3])),(*reinterpret_cast< QAction*(*)>(_a[4])),(*reinterpret_cast< QAction*(*)>(_a[5])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 20: text_DisplayUserText(); break;
        case 21: text_DisplayKernelText(); break;
        case 22: text_DisplayComments(); break;
        case 23: text_DisplayInstructionValue(); break;
        case 24: data_DisplayUserData(); break;
        case 25: data_DisplayUserStack(); break;
        case 26: data_DisplayKernelData(); break;
        case 27: data_DisplayBinary(); break;
        case 28: data_DisplayOctal(); break;
        case 29: data_DisplayHex(); break;
        case 30: data_DisplayDecimal(); break;
        case 31: { int _r = setCheckedDataSegmentBase((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 32: win_IntRegisters(); break;
        case 33: win_FPRegisters(); break;
        case 34: win_TextSegment(); break;
        case 35: win_DataSegment(); break;
        case 36: win_Console(); break;
        case 37: win_Tile(); break;
        case 38: help_ViewHelp(); break;
        case 39: help_AboutSPIM(); break;
        default: ;
        }
        _id -= 40;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
