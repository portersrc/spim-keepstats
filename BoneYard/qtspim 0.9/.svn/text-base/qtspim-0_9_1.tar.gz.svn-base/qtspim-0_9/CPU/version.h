#define SPIM_VERSION "Version 8.0 of January 8, 2010"
